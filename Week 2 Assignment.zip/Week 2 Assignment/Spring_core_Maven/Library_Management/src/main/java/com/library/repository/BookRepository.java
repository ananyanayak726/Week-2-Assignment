package com.library.repository;

public class BookRepository {
    // Method to perform some repository operation (for example, fetching books from the database)
    public void getBooks() {
        System.out.println("Fetching books from the database...");
    }
}
